import React from 'react';
import {View, StyleSheet,Text} from 'react-native';

const Khoanthu = () => {
    return (
        <View style={{alignItems:'center'}}>
            <Text>KHoanthu</Text>
            <Text>KHoanthu</Text>
            
        </View>
    );
}

const styles = StyleSheet.create({})

export default Khoanthu;
