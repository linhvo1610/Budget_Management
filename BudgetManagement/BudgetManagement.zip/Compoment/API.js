export const API = {
    login: 'http://192.168.2.140:8000/api/users?username=',
    register: 'http://192.168.2.140:8000/api/users',
}