import React from 'react';
import {View, StyleSheet, Text} from 'react-native';

const Thongke = () => {
    return (
        <View style={{alignItems:'center'}}>
            <Text>Thoongs kee</Text>
            <Text>Thoongs kee</Text>
            
            
        </View>
    );
}

const styles = StyleSheet.create({})

export default Thongke;
