import { Modal, Button, StyleSheet, Text, TextInput, Pressable, TouchableOpacity, View, Image, ToastAndroid } from 'react-native'
import React, { useEffect, useState } from 'react'
import { FlatList, RefreshControl, ScrollView } from 'react-native-gesture-handler'

const Khoanchi = (props) => {
    var url = "http://192.168.1.109:3000/tb_khoanchi"
    const [listcontact, setlistcontact] = useState([])
    const [reloading, setreloading] = useState(false)
    const [visibleModalDetail, setvisibleModalDetail] = useState(false)
    const [visibleModalDelete, setvisibleModalDelete] = useState(false)

    const [title, settitle] = useState("")
    const [price, setprice] = useState('')
    const [note, setnote] = useState('')
    const [date, setdate] = useState('')
    const [id_khoanchi, setIdkhoanchi] = useState()

    const getData = async () => {
        try {
            const response = await fetch(url); //lấy dữ liệu về 
            const jsonSP = await response.json(); // chuyển dũ liêu thành đt json
            setlistcontact(jsonSP);

        } catch (error) {
            console.error(error);
        } finally {
        }
    }

    console.log(id_khoanchi);

    const xoaKhoanchi = () => {
        var url = "http://192.168.1.109:3000/tb_khoanchi/" + id_khoanchi;
        fetch(url, {
            method: 'DELETE',
            headers: {
                Accept: 'application/json',
                'Content-Type': 'application/json',
            },
        })
            .then((response) => {
                if (response.status == 200) {
                    alert('Xóa thành công')
                    setvisibleModalDelete(false);
                    reloadData();
                }
            })
            .catch((err) => {
                console.log(err);
            });
    }

    useEffect(() => {
        getData();
    }, [])

    const reloadData = React.useCallback(() => {
        // xử lý công việc load lại dữ liệu đổ vào danh sách
        setreloading(true); // set trạng thái bắt đầu reload
        getData();
        // mô phỏng đợi reload, nếu là reload từ server thật thì không cần viết lệnh dưới
        setTimeout(() => {
            setreloading(false); // sau 2s thì đổi trạng thái không rload nữa
        }, 1500);
    });

    const chuyenAdd = () => {
        props.navigation.navigate('AddKhoanchi');
    }
    const quoaylai = () => {
        props.navigation.navigate('Home');
    }

    const renderContact = ({ item }) => {

        const selectData = () => {
            settitle(item.title),
                setprice(item.price),
                setnote(item.note),
                setdate(item.date),
                setIdkhoanchi(item.id)
        }

        return (
            <View>
                <View style={st.item}>

                    <View style={{ flexDirection: 'row', marginLeft: 10 }}>
                        <Text style={{ fontSize: 18, width: 50, }} >Title: </Text>
                        <TouchableOpacity style={{ marginLeft: 7, width: 250, flexDirection: 'row' }}
                            onPress={() => { setvisibleModalDetail(true), selectData(item.id) }}
                        >
                            <Text style={{ fontWeight: 'bold', color: 'black', fontSize: 18, }}>{item.title}</Text>
                        </TouchableOpacity>
                        <TouchableOpacity style={{ marginRight: -20 }}
                            onPress={() => {
                                props.navigation.navigate('UpdateKhoanchi', { item_thuchi: item })
                            }}
                        >
                            <Image style={st.img} source={{ uri: 'https://cdn-icons-png.flaticon.com/128/10308/10308391.png' }} />
                        </TouchableOpacity>
                    </View>

                    <View style={{ flexDirection: 'row', marginTop: 10, marginLeft: 10 }}>
                        <Text style={{ fontSize: 18, width: 50, }} >Price: </Text>
                        <TouchableOpacity style={{ marginLeft: 7, width: 250, flexDirection: 'row' }} >
                            <Text style={{ color: 'black', fontSize: 18, }}
                            >{item.price} vnđ</Text>
                        </TouchableOpacity>
                        <TouchableOpacity onPress={() => { setvisibleModalDelete(true), selectData(item.id) }}>
                            <Image style={st.img} source={{ uri: 'https://cdn-icons-png.flaticon.com/128/9068/9068885.png' }} />
                        </TouchableOpacity>
                    </View>
                </View>
            </View>

        )
    }

    return (
        <View style={{ flex: 1 }}>
            <View style={{ flexDirection: 'row', alignSelf: 'center', margin: 40 }}>
                <View style={{
                    backgroundColor: 'white', padding: 10, borderRadius: 20, elevation: 10, width: 300, alignSelf: 'center'
                }}>

                    <Text style={{ fontSize: 25, color: '#FF4500', backgroundColor: 'white', alignSelf: 'center', fontWeight: 'bold' }}>
                        Quản Lý Khoản Chi
                    </Text>
                </View>

                <TouchableOpacity onPress={chuyenAdd} >
                    <Image source={{ uri: 'https://cdn-icons-png.flaticon.com/128/2921/2921226.png' }}
                        style={{ width: 40, height: 40, marginLeft: 20, marginTop: 8 }}></Image>
                </TouchableOpacity>
            </View>
            <FlatList
                data={listcontact}
                keyExtractor={item => { return item.id }}
                refreshControl={
                    <RefreshControl refreshing={reloading} onRefresh={reloadData} />
                }
                renderItem={renderContact}
            >
            </FlatList>

            {/* Hiển Thị Phần Chi Tiết */}
            <View style={st.centeredView}>
                <Modal
                    animationType='fade'
                    transparent={true}
                    visible={visibleModalDetail}
                    onRequestClose={() => { setvisibleModalDetail(false) }}
                >
                    <View style={st.centeredView}>
                        <View style={st.modalView}>
                            <Text style={st.modalText}>Thông Tin Khoản Chi</Text>
                            <View style={[st.viewrowdetail]}>
                                <Image style={st.img_detail} source={{ uri: 'https://cdn-icons-png.flaticon.com/128/10203/10203290.png' }} />
                                <Text style={st.textItem}>: {id_khoanchi}</Text>
                            </View>
                            <View style={[st.viewrowdetail]}>
                                <Image style={st.img_detail} source={{ uri: 'https://cdn-icons-png.flaticon.com/128/6932/6932702.png' }} />
                                <Text style={st.textItem}>: {title}</Text>
                            </View>

                            <View style={[st.viewrowdetail]}>
                                <Image style={st.img_detail} source={{ uri: 'https://cdn-icons-png.flaticon.com/128/9340/9340193.png' }} />
                                <Text style={st.textItem}>: {price} VNĐ</Text>
                            </View>
                            <View style={[st.viewrowdetail]}>
                                <Image style={st.img_detail} source={{ uri: 'https://cdn-icons-png.flaticon.com/128/9358/9358504.png' }} />
                                <Text style={st.textItem}>: {date}</Text>
                            </View>
                            <View style={[st.viewrowdetail]}>
                                <Image style={st.img_detail} source={{ uri: 'https://cdn-icons-png.flaticon.com/128/5406/5406393.png' }} />
                                <Text style={st.textItem}>: {note}</Text>
                            </View>
                            <View style={{ flexDirection: 'row', alignItems: 'center', margin: 10 }}>
                                <Pressable
                                    style={[st.button]}
                                    onPress={() => setvisibleModalDetail(false)}>
                                    <Text style={st.textStyle}>Hide</Text>
                                </Pressable>
                            </View>
                        </View>
                    </View>
                </Modal>
            </View>

            {/* Hiển Thị Phần Xóa */}
            <View style={st.centeredView}>
                <Modal
                    animationType='fade'
                    transparent={true}
                    visible={visibleModalDelete}
                    onRequestClose={() => { setvisibleModalDelete(false) }}
                >
                    <View style={st.centeredView}>
                        <View style={st.modalViewz}>
                            <Text style={st.modalText}>Xóa Khoản Chi</Text>
                            <Text style={{ margin: 5, fontSize: 16, fontWeight: 'bold' }}>Bạn chắc chắn muốn xóa chứ?</Text>
                            <View style={{ flexDirection: 'row', alignItems: 'center', margin: 10 }}>
                                <Pressable
                                    style={[st.buttonDelete, { marginRight: 20, backgroundColor: '#00ff00' }]}
                                    onPress={xoaKhoanchi}
                                >
                                    <Text style={st.textStyle}>YES</Text>
                                </Pressable>
                                <Pressable
                                    style={[st.buttonDelete]}
                                    onPress={() => setvisibleModalDelete(false)}>
                                    <Text style={st.textStyle}>NO</Text>
                                </Pressable>
                            </View>
                        </View>
                    </View>
                </Modal>
            </View>

        </View>
    )
}

export default Khoanchi

const st = StyleSheet.create({
    img: {
        width: 27,
        height: 27,
    },
    item: {
        elevation: 10,
        margin: 10,
        backgroundColor: 'white',
        borderRadius: 20,
        padding: 10,
        borderColor: '#FF4500',
        borderWidth: 1,
    },
    save: {
        borderRadius: 20,
        width: 120, height: 40,
        backgroundColor: 'green',
        color: 'white',
        fontSize: 18,
        textAlign: 'center',
        padding: 5,
        fontWeight: 'bold'
    },

    modaldialog: {
        flex: 1,
        backgroundColor: 'white',
        margin: 30,
        alignItems: 'center',
        justifyContent: 'center',
        borderRadius: 20
    },
    textip: {
        borderWidth: 1.5,
        borderColor: 'orange',
        padding: 16,
        width: 300,
        height: 50,
        margin: 10,
        borderRadius: 25,
        fontSize: 17,
    },
    textipdate: {
        borderWidth: 1.5,
        borderColor: 'orange',
        padding: 16,
        width: 300,
        height: 50,
        margin: 10,
        borderRadius: 25,
        fontSize: 17,
    },
    centeredView: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center'
    },
    modalView: {
        backgroundColor: 'white',
        borderRadius: 20,
        padding: 15,
        alignItems: 'flex-start',
        shadowColor: '#000',
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.25,
        shadowRadius: 4,
        elevation: 5,
        width: '90%',

    },
    modalViewz: {
        backgroundColor: 'white',
        borderRadius: 20,
        padding: 15,
        alignItems: 'center',
        shadowColor: '#000',
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.25,
        shadowRadius: 4,
        elevation: 5,
        width: '90%',

    },
    button: {
        borderRadius: 20,
        padding: 10,
        elevation: 2,
        backgroundColor: 'red',
        width: 130,
        marginLeft: 95
    },
    buttonDelete: {
        borderRadius: 20,
        padding: 10,
        elevation: 2,
        backgroundColor: 'red',
        width: 130,
    },
    buttonOpen: {
        backgroundColor: '#F194FF',
    },

    textStyle: {
        color: 'white',
        fontWeight: 'bold',
        textAlign: 'center',
        fontSize: 15,

    },
    modalText: {
        marginBottom: 15,
        textAlign: 'center',
        fontWeight: 'bold',
        fontSize: 20,
        color: 'red',
        alignSelf: 'center'
    },
    img_detail: {
        width: 45,
        height: 45,
        marginRight: 10
    },
    viewrowdetail: {
        flexDirection: 'row',
        alignItems: 'center',
        margin: 10
    },
    textItem: {
        fontSize: 25,
    }
})